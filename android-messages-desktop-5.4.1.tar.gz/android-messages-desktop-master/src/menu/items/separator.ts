import { MenuItemConstructorOptions } from "electron";

export const separator: MenuItemConstructorOptions = { type: "separator" };
