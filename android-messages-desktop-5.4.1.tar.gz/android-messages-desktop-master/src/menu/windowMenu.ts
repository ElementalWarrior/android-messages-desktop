import { MenuItemConstructorOptions } from "electron";

export const windowMenuTemplate: MenuItemConstructorOptions = {
  label: "&Window",
  role: "windowMenu",
};
