module.exports = {
  trailingComma: "es5",
  arrowParens: "always",
};
